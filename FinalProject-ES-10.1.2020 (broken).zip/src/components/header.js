import React from "react";
// import { Link } from "react-router-dom";
import "./header.css";

// A bar at the top with the following items from left to right:
// Logo Icon; App Name; Settings Icon (a gear)

// function Header() {
//   return <Header></Header>;
// }

// export default Header;

//header from the quiz game app
function Header() {
  return (
    <header className="header">
      <nav className="header__nav">
        <ul>
          <li>
            <Link to="/">Home Page</Link>
          </li>
          <li>
            <Link to="/">Home Page</Link>
          </li>
          <li>
            <Link to="./settings-page">Settings</Link>
          </li>
        </ul>
      </nav>
    </header>
  );
}

export default Header;
