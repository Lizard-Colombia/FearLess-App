import React from "react";
// a function allowing the user to create items that appear in a list format
function FearList() {
  return <FearList></FearList>;
}

export default FearList;
