import React from "react";
//this component should filter the fear-list in 5 ways: All; A-Z; 1-10 or the reverse.
function Filter() {
  return <Filter></Filter>;
}

export default Filter;
