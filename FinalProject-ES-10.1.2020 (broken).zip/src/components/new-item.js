import React from "react";
// this should be a pop-up window when the plus sign is click to "add new item"
// it should allow the user to add an item called a "Fear" along with a field to rank
// the severity of the fear from 1-10
function NewItem() {
  return <NewItem></NewItem>;
}

export default NewItem;
