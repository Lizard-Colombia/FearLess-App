import React from "react";
// A bar at the bottom of the app with the following buttons in order form left to right:
// Progress; Profile; Emergency; Rewards; Task
function Footer() {
  return <Footer></Footer>;
}

export default Footer;
