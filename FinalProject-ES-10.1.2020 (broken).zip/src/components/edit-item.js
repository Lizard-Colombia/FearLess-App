import React from "react";
// Edit item should get the list item the user has selected and allow them to edit the description box and rank
function editItem() {
  return <editItem></editItem>;
}

export default editItem;
