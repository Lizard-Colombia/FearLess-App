import React from "react";

function FearListPage() {
  return <div>Fear List Page</div>;
}

export default FearListPage;
