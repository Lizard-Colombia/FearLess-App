import React from "react";

function ProfilePage() {
  return (
    <ProfilePage>
      <h1>
        This page is currently under construction. Thank you for your patience.
      </h1>
    </ProfilePage>
  );
}

export default ProfilePage;
