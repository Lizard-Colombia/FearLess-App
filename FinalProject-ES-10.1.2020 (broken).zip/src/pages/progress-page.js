import React from "react";

function ProgressPage() {
  return (
    <ProgressPage>
      <h1>
        This page is currently under construction. Thank you for your patience.
      </h1>
    </ProgressPage>
  );
}

export default ProgressPage;
