import React from "react";

function WelcomePage() {
  return <div>Welcome Page</div>;
}

export default WelcomePage;
