import React from "react";

function SettingsPage() {
  return (
    <SettingsPage>
      {" "}
      <h1>
        This page is currently under construction. Thank you for your patience.
      </h1>
    </SettingsPage>
  );
}

export default SettingsPage;
