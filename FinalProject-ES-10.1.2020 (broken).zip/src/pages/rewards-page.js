import React from "react";

function RewardsPage() {
  return (
    <RewardsPage>
      {" "}
      <h1>
        This page is currently under construction. Thank you for your patience.
      </h1>
    </RewardsPage>
  );
}

export default RewardsPage;
